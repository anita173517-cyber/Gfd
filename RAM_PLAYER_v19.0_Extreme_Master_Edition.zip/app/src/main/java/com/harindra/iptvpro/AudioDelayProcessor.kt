package com.harindra.iptvpro

import androidx.annotation.OptIn
import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import androidx.media3.common.util.UnstableApi
import java.nio.ByteBuffer

/**
 * Real-time PCM Audio Delay Processor for RAM PLAYER v19.0.
 *
 * Uses a bounded circular PCM ring buffer (max 500ms = ~96 KB at 48kHz stereo 16-bit)
 * so it is safe on 512MB RAM Android TV devices while genuinely shifting decoded PCM audio.
 * Note: Hardware bitstream passthrough (AC3/DTS/TrueHD) bypasses PCM AudioProcessors by design.
 */
@OptIn(UnstableApi::class)
class AudioDelayProcessor : BaseAudioProcessor() {

    companion object {
        const val MAX_DELAY_MS = 500
    }

    @Volatile
    private var targetDelayMs: Int = 0

    private var bytesPerMs: Int = 192 // default 48000 * 2 * 2 / 1000
    private var ringBuffer: ByteArray = ByteArray(1)
    private var writePos: Int = 0
    private var bufferedBytes: Int = 0
    private var configuredFormat: AudioProcessor.AudioFormat = AudioProcessor.AudioFormat.NOT_SET

    fun setDelayMs(delayMs: Int) {
        val clamped = delayMs.coerceIn(0, MAX_DELAY_MS)
        if (clamped != targetDelayMs) {
            targetDelayMs = clamped
            clearDelayBuffer()
        }
    }

    fun getDelayMs(): Int = targetDelayMs

    fun isPcmActive(): Boolean = configuredFormat != AudioProcessor.AudioFormat.NOT_SET

    @Synchronized
    fun clearDelayBuffer() {
        ringBuffer.fill(0)
        writePos = 0
        bufferedBytes = 0
    }

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        if (inputAudioFormat.encoding != C.ENCODING_PCM_16BIT) {
            configuredFormat = AudioProcessor.AudioFormat.NOT_SET
            return AudioProcessor.AudioFormat.NOT_SET
        }
        configuredFormat = inputAudioFormat
        val frameBytes = (inputAudioFormat.channelCount.coerceAtLeast(1)) * 2
        bytesPerMs = ((inputAudioFormat.sampleRate.toLong() * frameBytes) / 1000L).toInt().coerceAtLeast(frameBytes)
        val maxBytes = (bytesPerMs * MAX_DELAY_MS).coerceAtLeast(frameBytes)
        if (ringBuffer.size != maxBytes) {
            ringBuffer = ByteArray(maxBytes)
        } else {
            ringBuffer.fill(0)
        }
        writePos = 0
        bufferedBytes = 0
        return inputAudioFormat
    }

    @Synchronized
    override fun queueInput(inputBuffer: ByteBuffer) {
        val remaining = inputBuffer.remaining()
        if (remaining <= 0) return

        val delayMs = targetDelayMs
        if (delayMs <= 0 || ringBuffer.size <= 1) {
            val out = replaceOutputBuffer(remaining)
            out.put(inputBuffer)
            out.flip()
            return
        }

        val frameBytes = (configuredFormat.channelCount.coerceAtLeast(1)) * 2
        val desiredDelayBytes = ((delayMs * bytesPerMs) / frameBytes) * frameBytes
        val effectiveDelay = desiredDelayBytes.coerceIn(frameBytes, ringBuffer.size)

        val out = replaceOutputBuffer(remaining)
        val cap = ringBuffer.size
        for (i in 0 until remaining) {
            val incoming = inputBuffer.get()
            if (bufferedBytes < effectiveDelay) {
                ringBuffer[writePos] = incoming
                writePos = (writePos + 1) % cap
                bufferedBytes++
                out.put(0.toByte())
            } else {
                val readPos = (writePos - effectiveDelay + cap) % cap
                val delayedByte = ringBuffer[readPos]
                ringBuffer[writePos] = incoming
                writePos = (writePos + 1) % cap
                out.put(delayedByte)
            }
        }
        out.flip()
    }

    override fun onReset() {
        clearDelayBuffer()
        configuredFormat = AudioProcessor.AudioFormat.NOT_SET
    }
}
