package com.harindra.iptvpro

import android.content.Context
import android.util.Log
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Request
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.concurrent.TimeUnit

/**
 * Reliable WorkManager background playlist refresh worker for RAM PLAYER v19.0.
 *
 * - Network-aware (`NetworkType.CONNECTED`) and battery-conscious (`setRequiresBatteryNotLow(true)`).
 * - Uses `ExistingPeriodicWorkPolicy.UPDATE` to prevent duplicate refresh schedules.
 * - Retries transient failures up to 3 times with exponential backoff.
 */
class PlaylistRefreshWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val profileStore = ProfileStore(applicationContext)
        val activeId = profileStore.activeId()
        val profile = profileStore.all().firstOrNull { it.id == activeId }
            ?: return@withContext Result.success()
        val scope = profile.id
        val cacheStore = ChannelCacheStore(applicationContext)

        try {
            when (profile.type) {
                ProfileType.M3U -> {
                    val url = profile.source.trim()
                    if (!url.startsWith("http://", ignoreCase = true) && !url.startsWith("https://", ignoreCase = true)) {
                        profileStore.recordPlaylistRefreshResult(true, "Local M3U skipped in background", scope)
                        return@withContext Result.success()
                    }
                    val req = Request.Builder()
                        .url(url)
                        .header("User-Agent", NetworkClient.DEFAULT_USER_AGENT)
                        .build()
                    NetworkClient.apiClient.newCall(req).execute().use { resp ->
                        if (!resp.isSuccessful) {
                            throw IllegalStateException("HTTP ${resp.code}")
                        }
                        val body = resp.body ?: throw IllegalStateException("Empty response")
                        val parsed = BufferedReader(InputStreamReader(body.byteStream(), Charsets.UTF_8)).use { reader ->
                            M3uParser.parse(reader, maxChannels = 60_000)
                        }
                        if (parsed.isNotEmpty()) {
                            cacheStore.saveChannels(scope, parsed)
                            profileStore.recordPlaylistRefreshResult(
                                true,
                                "Background M3U refresh: ${parsed.size} channels",
                                scope
                            )
                        } else {
                            profileStore.recordPlaylistRefreshResult(false, "Background M3U returned 0 channels", scope)
                        }
                    }
                }
                ProfileType.XTREAM -> {
                    val creds = XtreamCredentials(profile.name, profile.source, profile.username, profile.password)
                    val repo = XtreamRepository()
                    val result = repo.fetchLiveStreams(creds)
                    val liveChannels = result.getOrThrow()
                    if (liveChannels.isNotEmpty()) {
                        cacheStore.saveChannels(scope, liveChannels)
                        profileStore.recordPlaylistRefreshResult(
                            true,
                            "Background Xtream refresh: ${liveChannels.size} Live channels",
                            scope
                        )
                    } else {
                        profileStore.recordPlaylistRefreshResult(false, "Background Xtream returned 0 channels", scope)
                    }
                }
            }
            val hours = profileStore.getAutoRefreshIntervalHours(scope)
            if (hours > 0) {
                profileStore.setNextScheduledRefreshEpochMs(
                    System.currentTimeMillis() + hours * 3_600_000L,
                    scope
                )
            }
            Result.success()
        } catch (e: Exception) {
            Log.w("RAMPlayerWork", "Background playlist refresh attempt $runAttemptCount failed: ${e.message}")
            profileStore.recordPlaylistRefreshResult(false, "Retry $runAttemptCount: ${e.message ?: "Network error"}", scope)
            if (runAttemptCount < 3) Result.retry() else Result.failure()
        }
    }

    companion object {
        const val UNIQUE_WORK_NAME = "ram_player_periodic_playlist_refresh"

        fun schedulePeriodicRefresh(context: Context, intervalHours: Int, accountScope: String) {
            val wm = WorkManager.getInstance(context.applicationContext)
            val store = ProfileStore(context.applicationContext)
            if (intervalHours <= 0) {
                wm.cancelUniqueWork(UNIQUE_WORK_NAME)
                store.setNextScheduledRefreshEpochMs(0L, accountScope)
                return
            }
            val safeHours = intervalHours.coerceIn(1, 168).toLong()
            val constraints = Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .setRequiresBatteryNotLow(true)
                .build()
            val req = PeriodicWorkRequestBuilder<PlaylistRefreshWorker>(safeHours, TimeUnit.HOURS)
                .setConstraints(constraints)
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 15, TimeUnit.MINUTES)
                .build()
            wm.enqueueUniquePeriodicWork(
                UNIQUE_WORK_NAME,
                ExistingPeriodicWorkPolicy.UPDATE,
                req
            )
            store.setNextScheduledRefreshEpochMs(
                System.currentTimeMillis() + safeHours * 3_600_000L,
                accountScope
            )
        }

        fun cancelScheduledRefresh(context: Context, accountScope: String) {
            WorkManager.getInstance(context.applicationContext).cancelUniqueWork(UNIQUE_WORK_NAME)
            ProfileStore(context.applicationContext).setNextScheduledRefreshEpochMs(0L, accountScope)
        }
    }
}
